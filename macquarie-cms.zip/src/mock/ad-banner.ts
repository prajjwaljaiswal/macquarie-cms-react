export const AdBannerData = [
  {
    id: 1,
    url: "http://dummyimage.com/112x100.png/5fa2dd/ffffff",
  },
  {
    id: 2,
    url: "http://dummyimage.com/102x100.png/ff4444/ffffff",
  },
  {
    id: 3,
    url: "http://dummyimage.com/149x100.png/5fa2dd/ffffff",
  },
  {
    id: 4,
    url: "http://dummyimage.com/143x100.png/dddddd/000000",
  },
  {
    id: 5,
    url: "http://dummyimage.com/104x100.png/cc0000/ffffff",
  },
  {
    id: 6,
    url: "http://dummyimage.com/150x100.png/dddddd/000000",
  },
  {
    id: 7,
    url: "http://dummyimage.com/118x100.png/cc0000/ffffff",
  },
  {
    id: 8,
    url: "http://dummyimage.com/203x100.png/dddddd/000000",
  },
  {
    id: 9,
    url: "http://dummyimage.com/109x100.png/5fa2dd/ffffff",
  },
  {
    id: 10,
    url: "http://dummyimage.com/242x100.png/ff4444/ffffff",
  },
  {
    id: 11,
    url: "https://www.industrialempathy.com/img/remote/ZiClJf-1920w.jpg",
  },
];
