
import React from "react";
import "./LiveMatricsContract.css";

export default function LiveMatricsContract() {
  return <div className="live-matrics-contract">Live Matrics Contract</div>;
}
