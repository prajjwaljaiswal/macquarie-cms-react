
import React from "react";
import "./Email.css";

export default function Email() {
  return <div className="video-banner">Email Component</div>;
}
